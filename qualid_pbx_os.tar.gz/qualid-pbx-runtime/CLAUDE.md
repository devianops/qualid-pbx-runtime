# Quali-D PBX Runtime — Claude Code Instructions

This is the **public runtime repo** (`devianops/qualid-pbx-runtime`).
It contains only the files that run on live PBX devices.

**DO NOT edit files here directly.** All edits happen in the private source repo
and are synced here by `release.sh`.

---

## Two-repo layout

| Repo | Windows path | GitHub |
|------|-------------|--------|
| **qualid-pbx-os** (private, source) | `e:\My Python Projects 2025\Quali-D Softphone 2026\Quali-D PBX\` | devianops/qualid-pbx-os |
| **qualid-pbx-runtime** (public, this repo) | `e:\My Python Projects 2025\Quali-D Softphone 2026\Quali-D PBX Runtime\` | devianops/qualid-pbx-runtime |

---

## How to make a change and release it

```bash
# 1. Edit the file(s) in the SOURCE repo (qualid-pbx-os)
#    e.g. e:\My Python Projects 2025\Quali-D Softphone 2026\Quali-D PBX\setup-wizard\active.html

# 2. Commit to source repo
cd "e:/My Python Projects 2025/Quali-D Softphone 2026/Quali-D PBX"
git add <files>
git commit -m "describe the change"

# 3. Run the release script — does everything in one command
./release.sh 1.x.y
```

`release.sh` automatically:
1. Bumps `VERSION` in source repo, commits, pushes
2. Extracts LF-clean files (`git show HEAD:<file>`) into this runtime repo
3. Bumps `VERSION` here, commits, pushes
4. Stages and builds `qualid_pbx_os.tar.gz` with correct structure:
   - `install.sh` at tarball root (compatibility shim)
   - `qualid-pbx-runtime/` directory (all runtime files)
5. Creates a GitHub release on this repo

---

## Tarball structure (what devices receive)

```
qualid_pbx_os.tar.gz
├── install.sh                        ← shim: delegates to sync-scripts/install.sh
└── qualid-pbx-runtime/
    ├── agi-bin/
    ├── setup-wizard/
    ├── sync-scripts/
    │   ├── install.sh                ← real installer (runs as root)
    │   └── update.sh                 ← auto-updater (deployed to /usr/share/qualid/)
    ├── systemd/
    └── VERSION
```

---

## Files in this repo — what each does

| File/Dir | Purpose |
|----------|---------|
| `install.sh` | Tarball-root shim — for backward compat with old `update.sh` versions that look for `${TMP_DIR}/install.sh` |
| `sync-scripts/install.sh` | Real installer — copies files, writes configs, sets up systemd, PHP, sudoers |
| `sync-scripts/update.sh` | Auto-updater — checks GitHub releases, downloads tarball, runs install.sh |
| `sync-scripts/functions.inc.php` | FreePBX module sync logic |
| `sync-scripts/sync.php` | Cron sync entry point |
| `setup-wizard/api.php` | Web wizard backend (PHP) |
| `setup-wizard/active.html` | "PBX is Active" page — includes update UI |
| `setup-wizard/diagnose.html` | Diagnostics page |
| `setup-wizard/index.html` | Setup wizard main page |
| `setup-wizard/nginx-*.conf` | Nginx site configs (wizard + active) |
| `systemd/qualid-updater.*` | Auto-update systemd service + hourly timer |
| `systemd/qualid-sync.*` | Config sync systemd service + 5-min timer |
| `agi-bin/` | Asterisk AGI scripts for IVR |
| `VERSION` | Current deployed version string |
| `.gitattributes` | Enforces LF line endings on all files |

---

## Notes

- **Never** commit changes directly to this repo — always go through `release.sh`
- This `CLAUDE.md` is gitignored — it is local-only documentation
- The `qualid_pbx_os.tar.gz` file in this directory is a leftover build artifact — ignore it
